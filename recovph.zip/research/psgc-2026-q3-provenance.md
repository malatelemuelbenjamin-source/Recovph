# PSA Philippine Standard Geographic Code (PSGC), Third Quarter 2026

## Source and version

The newest PSGC masterlist on the implementation date (9 November 2026) was the PSA **Philippine Standard Geographic Code as of 30 September 2026**, published in the **Third Quarter 2026 PSGC Updates** release on 12 October 2026. The official PSA page says the Q3 changes corrected one barangay name and incorporated 2024 Census of Population urban/rural classifications; no local-government unit totals changed from the June 2026 release.

The official source workbook is [PSGC-3Q-2026-Publication-Datafile.xlsx](https://psa.gov.ph/system/files/scd/PSGC-3Q-2026-Publication-Datafile.xlsx), linked from PSA’s [PSGC publications page](https://psa.gov.ph/classification/psgc/barangays). The release note is [Third Quarter 2026 PSGC Updates](https://psa.gov.ph/classification/psgc/node/1684084314). The overall reference page is [Philippine Standard Geographic Code](https://psa.gov.ph/classification/psgc). A specific PSGC record page for the Special Geographic Area municipality Kapalawan is [Municipality of Kapalawan](https://psa.gov.ph/classification/psgc/barangays/1999901000).

## Workbook fields and verified level totals

The official workbook’s `PSGC` worksheet contains the columns `10-digit PSGC`, `Name`, `Correspondence Code`, `Geographic Level`, `Old names`, `City Class`, `Income Classification`, `Urban / Rural (based on 2024 CPH)`, `2024 Population`, and `Status`. For RECOVPH’s geographic directory, only the official code, official name, geographic level, city class, needed administrative status/notes, and derived parent codes are required; income classification, urban/rural, population, and unrelated workbook content are not part of the website dataset.

The workbook contains 43,768 rows with a code and name when informational notes and blank rows are excluded. Explicit PSGC geographic-level counts are: 18 `Reg`; 82 `Prov`; 149 `City`; 1,493 `Mun`; 42,010 `Bgy`; and 14 `SubMun`. The 149 City-level rows are classified as 33 HUC, 111 CC, and 5 ICC. City class values and geographic levels are stored as separate fields and must not be conflated.

Two coded/name-bearing records have a blank `Geographic Level`: `0990100000`, “City of Isabela (Not a Province),” and `1999900000`, “Special Geographic Area.” They remain separately visible and keep their official codes; they are not silently promoted to a province, city-level total, or municipality. Blank rows and a narrative footnote are not geographic entries. PSGCs are stored as strings, zero-padded to preserve every digit.

## Geographic exceptions and display rules

- **National Capital Region (NCR):** official region code `1300000000`; no Province-level rows use its region prefix. Pateros is a municipality directly within NCR and is not forced into a province.
- **City of Isabela:** code `0990100000` is the blank-level source row “City of Isabela (Not a Province).” Model it as a special province-code grouping under Region IX, not as a Province or City-level total. Its actual child `0990101000` City of Isabela has `Geographic Level=City` and `City Class=CC`; keep that City record under the special grouping and Region IX. The workbook note says that, although the city is geographically within Basilan, it is administratively part of Region IX and has this special province code. Do not attach the child city to Basilan or to BARMM.
- **Bangsamoro Special Geographic Area:** grouping code `1999900000`, with its municipality and barangay children in the same `19` code branch as the official BARMM region `1900000000`. Keep it as a distinct special grouping, not as a province or region. The PSA Kapalawan record confirms its municipality classification and official code.
- **City of Manila:** the workbook has 14 `SubMun` records. The workbook’s Notes sheet says these sub-municipalities/Municipal Districts have special municipality codes but are not officially recognized as municipalities. Preserve them as a distinct optional level, never inflate the official municipality count.
- **Lucena City:** code `0431200000`, City class `HUC`, retains its current PSGC assignment to Quezon `0405600000`; this parent is an explicit PSA-noted exception rather than a matching code-prefix relationship. The Q3 2026 PSA release explains that HUC treatment is for statistical purposes, pending statutory requirements, and is not a legal ruling on Lucena’s city status. Preserve its source assignment and show the qualification beside its classification.
- **HUC/ICC/CC:** preserve the distinct source class. Do not derive the parent province solely from a physical location. Component cities and municipalities use the appropriate PSGC code parent. Highly urbanized/independent city records stay under their source-assigned administrative level. Special cases above are explicit rather than fabricated.

## Data-display boundary

The PSGC workbook is a coded hierarchy dataset, not a geographic boundary/polyline dataset. RECOVPH therefore uses the existing Philippine archipelago illustration only as a labeled illustration and provides accurate selection through region cards and selectors; it does not make unsupported region polygons or click locations on an inaccurate map. All displayed coverage is informational and planned, not operational. Counts on the site are computed from the normalized source data.
